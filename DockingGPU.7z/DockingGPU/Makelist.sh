#! /bin/bash

> ligands.list

# List all files in the current directory
for file in *.maps.fld; do
    echo "$file" >> ligands.list
done

for file in ./ligands/*; do
    if [ -f "$file" ]; then
        echo "$file" >> ligands.list
        echo "$(basename $file)" >> ligands.list
    fi
done
