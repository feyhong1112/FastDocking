#!/bin/bash


filenum=0
end=1

while read -r line; do
    if [[ $end -eq 1 ]]; then
        end=0
        filenum=$((filenum + 1))
        exec 3>"molecule${filenum}.sdf"
    fi
    echo "$line" 1>&3
    if [[ "$line" = '$$$$' ]]; then
        end=1
        exec 3>&-
    fi
done


# Specify the directory containing your files
input_dir="$(dirname "$0")"

# Loop through each file in the directory
for file in "$input_dir"/*; do
    if [[ -f "$file" ]]; then
        # Extract the line after "> <chembl_id>"
        chembl_id=$(grep -oP '(?<=> <chembl_id>).+' "$file")
        if [[ -n "$chembl_id" ]]; then
            # Rename the file
            new_name="${chembl_id}.sdf"
            mv "$file" "$input_dir/$new_name"
            echo "Renamed $file to $new_name"
        else
            # If <chembl_id> not found, try <Formula>
            formula=$(grep -oP '(?<=> <Formula>).+' "$file")
            if [[ -n "$formula" ]]; then
                # Rename the file
                new_name="${formula}.sdf"
                mv "$file" "$input_dir/$new_name"
                echo "Renamed $file to $new_name"
            else
                echo "No <chembl_id> or <Formula> found in $file"
            fi
        fi
    fi
done