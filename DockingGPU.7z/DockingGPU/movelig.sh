#!/bin/bash

mkdir -p ligands
mv *.sdf ligands/

